import React from 'react'
import Header from './Components/Header/Header'
import Top from './Components/Top/Top'
import Hero from './Components/Hero/Hero'
import Support from './Components/Support/Support'
import Slider from './Components/Slider/Slider'
import Services from './Components/Services/Services'
import About from './Components/About/About'
import Team from './Components/Team/Team'
import Counter from './Components/Counter/Counter'
import Package from './Components/Package/Package'
import Suscribe from './Components/Suscribe/Suscribe'
import Project from './Components/Project/Project'
import News from './Components/News&Article/News'
import Contactus from './Components/Contactus/Contactus'
import Footer from './Components/Footer/Footer'




const App = () => {
  return (
    <>
    <Top/>
    <Header/>
    <Hero/>
    <Support/>
    <Slider/>
    <Services/>
    <About/>
    <Team/>
    <Counter/>
    <Package/>
    <Suscribe/>
    <Project/>
    <News/>
    <Contactus/>
    <Footer/>
    
    
       
   
    </>
  )
}

export default App